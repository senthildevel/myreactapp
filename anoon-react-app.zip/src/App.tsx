import { useState } from "react";
import Heading from "./Heading";
import Alert from "./components/Alert";
import Button from "./components/Button";
import ListGroup from "./components/ListGroup";
import "./App.css";
import Like from "./components/ListGroup/Like";
import StateHook from "./components/StateHook";
import Message from "./components/Message";
import StateHook1 from "./components/StateHook1";
import NavBar from "./components/NavBar";
import Cart from "./components/Cart";
import StateExercise from "./components/StateExercise";
import ExpandableText from "./components/ExpandableText";
import Form from "./components/Form";

// Fucntion based component
function App() {
  //let cities = ["Chennai", "Mumbai", "Bangalore", "Hyderabad", "Punjab"];
  let colors = ["Red", "Blue", "Green"];
  let heading = "Colors";

  const handleSelected = (item: string) => {
    console.log("Parent component ", item);
  };

  const [alertVisible, setAletVisibility] = useState(false);

  const [cartData, setCartItems] = useState([
    "Product 1 ",
    "Product 2",
    "Product 3",
  ]);

  // Consumer / parent
  // JSX
  return (
    <>
      <Form></Form>
      {/* <ExpandableText maxChars={100}>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corrupti
        ratione magnam in animi quaerat similique veniam error minima aperiam,
        ea quibusdam esse. Perferendis, exercitationem pariatur?
      </ExpandableText> */}
      {/* <StateExercise></StateExercise> */}

      {/* <NavBar cartItemsCount={cartData.length}></NavBar>
      <Cart cartItems={cartData} onClear={() => setCartItems([])}></Cart> */}

      {/* <StateHook1 /> */}
      {/*  <Message />
      <Message />
      <Message />
       <Like onLike={() => console.log("Like btn clicked")} />
     {alertVisible && (
        <Alert text="role" onClose={() => setAletVisibility(false)}>
          This is <strong>Alert</strong>. with close button enabled
        </Alert>
      )}
      <Button
        buttonType="danger"
        onClick={() => setAletVisibility(true)}
      ></Button> */}
      {/* <ListGroup
        items={colors}
        title={heading}
        onSelectedItem={handleSelected}
      /> */}
      {/* <ListGroup items={colors} /> */}
    </>
  );
}

export default App;
