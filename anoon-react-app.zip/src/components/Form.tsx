import { FormEvent, useRef } from "react";

const Form = () => {
  const nameRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();

    if (nameRef.current !== null) console.log(nameRef.current.value);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="username" className="form-label">
          Username
        </label>
        <input
          ref={nameRef}
          id="username"
          type="text"
          className="form-control"
        />
      </div>

      <div className="form-group">
        <label htmlFor="age" className="form-label">
          Age
        </label>
        <input id="age" type="number" className="form-control" />
      </div>
      <div className="mt-3">
        <button className="btn btn-primary">Submit</button>
      </div>
    </form>
  );
};

export default Form;
