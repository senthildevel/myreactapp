const Message = () => {
  let count = 0;
  count++;
  console.log("Message Called", count);

  return <div>Message {count}</div>;
};
export default Message;
