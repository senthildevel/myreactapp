import { useState } from "react";
import Heading from "./Heading";
import Alert from "./components/Alert";
import Button from "./components/Button";
import ListGroup from "./components/ListGroup";
import "./App.css";

// Fucntion based component
function App() {
  //let cities = ["Chennai", "Mumbai", "Bangalore", "Hyderabad", "Punjab"];
  let colors = ["Red", "Blue", "Green"];
  let heading = "Colors";

  const handleSelected = (item: string) => {
    console.log("Parent component ", item);
  };

  const [alertVisible, setAletVisibility] = useState(false);

  // Consumer / parent
  // JSX
  return (
    <>
      {/* {alertVisible && (
        <Alert text="role" onClose={() => setAletVisibility(false)}>
          This is <strong>Alert</strong>. with close button enabled
        </Alert>
      )}
      <Button
        buttonType="danger"
        onClick={() => setAletVisibility(true)}
      ></Button> */}

      <ListGroup
        items={colors}
        title={heading}
        onSelectedItem={handleSelected}
      />

      {/* <ListGroup items={colors} /> */}
    </>
  );
}

export default App;
