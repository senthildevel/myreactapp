import Heading from "./Heading";
import Alert from "./components/Alert";
import ListGroup from "./components/ListGroup";

// Fucntion based component
function App() {
  //let cities = ["Chennai", "Mumbai", "Bangalore", "Hyderabad", "Punjab"];
  let colors = ["Red", "Blue", "Green"];
  let heading = "Colors";

  const handleSelected = (item: string) => {
    console.log("Parent component ", item);
  };

  // Consumer / parent
  // JSX
  return (
    <>
      <Alert text="role">
        This is <strong>Alert</strong>
      </Alert>
      <ListGroup
        items={colors}
        title={heading}
        onSelectedItem={handleSelected}
      />

      {/* <ListGroup items={colors} /> */}
    </>
  );
}

export default App;
