function Heading(){

     let social_brand = "Yahoo";

    return <h1>{social_brand} Search - keyword </h1>

}

export default Heading;