import { useState } from "react";

// Reusable componenet
interface ListGroupProps {
  // items [], heading:string
  items: string[];
  title: string;
  onSelectedItem: (item: string) => void;
}
// items
function ListGroup({ items, title, onSelectedItem }: ListGroupProps) {
  // Shape of the component

  //cities = [];
  // const heading = "Cities";

  // state
  let [selectedItem, setSelectedItem] = useState(-1);
  //  args[0] data to be changed
  //  args[1] updater function

  // let message = (cities.length > 0) ? cities : "No Items Found";
  //map
  let cityList = items.map((item, index) => (
    <li
      key={item}
      onClick={() => {
        setSelectedItem(index);
        onSelectedItem(item); // parent.handleSelected(item)
      }}
      className={
        selectedItem == index ? "list-group-item active" : "list-group-item"
      }
    >
      {item}
    </li>
  ));

  //let message = cities.length == 0 && "No Items Found";

  // function getMessage() {
  //   return cities.length == 0 && "No Items Found";
  // }

  let getMessage = () => {
    return items.length == 0 && "No Items Found";
  };

  return (
    <>
      <h1>{title}</h1>
      {getMessage()}
      <ul className="list-group">{cityList}</ul>
    </>
  );
}

export default ListGroup;
